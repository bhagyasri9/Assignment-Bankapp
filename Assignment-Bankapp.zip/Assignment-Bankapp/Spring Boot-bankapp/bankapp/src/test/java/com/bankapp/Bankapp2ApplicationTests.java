package com.bankapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Bankapp2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
